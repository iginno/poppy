# ARPy

Simple Hamming Marker Detection using OpenCV


## Hamming Markers
Markers are encoded using [Hamming(7, 4) code](http://en.wikipedia.org/wiki/Hamming_code). 

A very simple exemple can be seen [here](http://nbviewer.ipython.org/github/pierre-rouanet/hampy/blob/master/notebooks/demo.ipynb).
